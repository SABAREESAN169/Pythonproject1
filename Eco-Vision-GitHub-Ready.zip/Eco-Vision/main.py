
import os
import csv
from datetime import datetime
from pathlib import Path
from typing import List, Tuple, Optional

import numpy as np
import cv2

# Try YOLO (ultralytics). If not available, run in demo mode.
YOLO_AVAILABLE = True
MODEL_PATH = Path("models") / "yolov8n-waste.pt"
try:
    from ultralytics import YOLO  # type: ignore
except Exception:
    YOLO_AVAILABLE = False

import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk

import pandas as pd
import matplotlib.pyplot as plt

LOGS_DIR = Path("logs")
LOGS_DIR.mkdir(parents=True, exist_ok=True)
LOG_CSV = LOGS_DIR / "detections.csv"

CLASSES_FILE = Path("waste_classes.txt")
if CLASSES_FILE.exists():
    with open(CLASSES_FILE, "r", encoding="utf-8") as f:
        WASTE_CLASSES = [line.strip() for line in f if line.strip()]
else:
    WASTE_CLASSES = ["recyclable", "organic", "hazardous", "e-waste", "other"]

def ensure_log_header():
    if not LOG_CSV.exists():
        with open(LOG_CSV, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow(["timestamp", "image_path", "category", "confidence", "notes"])

def log_detection(image_path: str, category: str, confidence: float, notes: str = ""):
    ensure_log_header()
    with open(LOG_CSV, "a", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow([datetime.now().isoformat(timespec="seconds"), image_path, category, f"{confidence:.2f}", notes])

def dominant_color_classification(img_bgr: np.ndarray) -> Tuple[str, float]:
    # Heuristic demo classifier: maps dominant hue to a waste category.
    img = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
    hue = img[:, :, 0]
    mean_hue = float(np.mean(hue))
    if mean_hue < 15 or mean_hue > 165:
        category, conf = "hazardous", 0.55
    elif 15 <= mean_hue < 45:
        category, conf = "organic", 0.60
    elif 45 <= mean_hue < 75:
        category, conf = "recyclable", 0.65
    elif 75 <= mean_hue < 120:
        category, conf = "e-waste", 0.58
    else:
        category, conf = "other", 0.50
    if category not in WASTE_CLASSES:
        category = "other"
    return category, conf

class Detector:
    def __init__(self):
        self.mode = "demo"
        self.model = None
        if YOLO_AVAILABLE and MODEL_PATH.exists():
            try:
                self.model = YOLO(str(MODEL_PATH))
                self.mode = "yolo"
            except Exception as e:
                print(f"[WARN] YOLO load failed: {e}. Using demo mode.")
                self.mode = "demo"
        else:
            self.mode = "demo"

    def detect_image(self, image_path: str):
        # Returns annotated image (BGR) and detections: list of (label, conf, (x1,y1,x2,y2)).
        img = cv2.imread(image_path)
        if img is None:
            raise ValueError("Failed to read image.")
        if self.mode == "yolo" and self.model is not None:
            results = self.model(img)[0]
            dets = []
            for box in results.boxes:
                xyxy = box.xyxy.cpu().numpy().astype(int)[0]
                conf = float(box.conf.cpu().numpy()[0])
                cls_id = int(box.cls.cpu().numpy()[0])
                label = self.model.names.get(cls_id, "object")
                mapped = label if label in WASTE_CLASSES else "other"
                dets.append((mapped, conf, (int(xyxy[0]), int(xyxy[1]), int(xyxy[2]), int(xyxy[3]))))
            annotated = img.copy()
            for (lab, cf, (x1,y1,x2,y2)) in dets:
                cv2.rectangle(annotated, (x1,y1), (x2,y2), (0,255,0), 2)
                cv2.putText(annotated, f"{lab} {cf:.2f}", (x1, max(0,y1-5)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)
            if not dets:
                lab, cf = dominant_color_classification(img)
                dets = [(lab, cf, (10,10, min(200, img.shape[1]-10), min(80, img.shape[0]-10)))]
                cv2.putText(annotated, f"{lab} {cf:.2f}", (15, 35), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,0), 2)
            return annotated, dets
        else:
            lab, cf = dominant_color_classification(img)
            dets = [(lab, cf, (10,10, min(200, img.shape[1]-10), min(80, img.shape[0]-10)))]
            annotated = img.copy()
            cv2.putText(annotated, f"{lab} {cf:.2f}", (15, 35), cv2.FONT_HERSHEY_SIMPLEX, 1, (255,255,0), 2)
            return annotated, dets

class App:
    def __init__(self, root):
        self.root = root
        self.root.title("Eco Vision - Waste Classification")
        self.detector = Detector()

        self.image_path: Optional[str] = None
        self.cv_img: Optional[np.ndarray] = None
        self.tk_img = None

        top = tk.Frame(root)
        top.pack(fill=tk.X, pady=6)

        self.btn_open = tk.Button(top, text="Open Image", command=self.open_image, width=15)
        self.btn_open.pack(side=tk.LEFT, padx=5)

        self.btn_detect = tk.Button(top, text="Run Detection", command=self.run_detection, width=15)
        self.btn_detect.pack(side=tk.LEFT, padx=5)

        self.btn_chart = tk.Button(top, text="Show Pie Chart", command=self.show_pie_chart, width=15)
        self.btn_chart.pack(side=tk.LEFT, padx=5)

        self.btn_info = tk.Button(top, text="Info", command=self.show_info, width=10)
        self.btn_info.pack(side=tk.LEFT, padx=5)

        self.label_mode = tk.Label(top, text=f"Mode: {self.detector.mode.upper()}",
                                   fg=("green" if self.detector.mode == "yolo" else "orange"))
        self.label_mode.pack(side=tk.RIGHT, padx=10)

        self.canvas = tk.Label(root)
        self.canvas.pack(padx=10, pady=10)

        self.status = tk.Label(root, text="Ready", anchor="w")
        self.status.pack(fill=tk.X)

    def show_info(self):
        msg = "Eco Vision\n"
        msg += f"Detection mode: {self.detector.mode.upper()}\n"
        if self.detector.mode != "yolo":
            msg += "Tip: Put your YOLOv8 weights in ./models (e.g., yolov8n-waste.pt)\n"
        messagebox.showinfo("About", msg)

    def open_image(self):
        path = filedialog.askopenfilename(title="Select Image",
                                          filetypes=[("Image Files", "*.jpg *.jpeg *.png *.bmp")])
        if not path:
            return
        self.image_path = path
        bgr = cv2.imread(path)
        if bgr is None:
            messagebox.showerror("Error", "Failed to load image.")
            return
        self.cv_img = bgr
        self.show_image(bgr)
        self.status.config(text=f"Loaded: {os.path.basename(path)}")

    def run_detection(self):
        if not self.image_path:
            messagebox.showwarning("No Image", "Please open an image first.")
            return
        try:
            annotated, dets = self.detector.detect_image(self.image_path)
            self.cv_img = annotated
            self.show_image(annotated)
            if dets:
                dets_sorted = sorted(dets, key=lambda d: d[1], reverse=True)
                top_label, top_conf, _ = dets_sorted[0]
                log_detection(self.image_path, top_label, top_conf, notes=f"mode={self.detector.mode}")
                self.status.config(text=f"Detected: {top_label} ({top_conf:.2f})")
            else:
                self.status.config(text="No detections.")
        except Exception as e:
            messagebox.showerror("Detection Error", str(e))

    def show_image(self, bgr: np.ndarray, max_w: int = 960, max_h: int = 640):
        h, w = bgr.shape[:2]
        scale = min(max_w / w, max_h / h, 1.0)
        if scale < 1.0:
            bgr = cv2.resize(bgr, (int(w*scale), int(h*scale)))
        rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(rgb)
        self.tk_img = ImageTk.PhotoImage(image=img)
        self.canvas.config(image=self.tk_img)

    def show_pie_chart(self):
        if not LOG_CSV.exists():
            messagebox.showinfo("No Data", "No logs found yet. Run detection first.")
            return
        try:
            df = pd.read_csv(LOG_CSV)
            if df.empty:
                messagebox.showinfo("No Data", "Log file is empty.")
                return
            counts = df["category"].value_counts()
            plt.figure()
            plt.pie(counts.values, labels=counts.index, autopct="%1.1f%%")
            plt.title("Waste Category Distribution")
            plt.show()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to plot chart: {e}")

def main():
    ensure_log_header()
    root = tk.Tk()
    app = App(root)
    root.mainloop()

if __name__ == "__main__":
    main()
