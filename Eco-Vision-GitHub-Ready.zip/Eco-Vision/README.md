
# Eco Vision: Automated Waste Classification for Clean Communities Using Machine Learning

Eco Vision is a Python project that uses YOLO (via Ultralytics) to classify waste items and recommend the correct bin.
It ships with a Tkinter GUI, CSV logging, and a pie chart dashboard. If YOLO weights are not present, it runs a Demo Mode
so you can still verify the full workflow end-to-end.

## Features
- YOLOv8-ready (drop your weights into `models/`).
- Demo Mode when weights or Ultralytics are missing.
- Tkinter GUI for image selection and detection.
- Logging to `logs/detections.csv`.
- Pie chart of category distribution.

## Project Structure
Eco-Vision/
├── main.py
├── requirements.txt
├── waste_classes.txt
├── models/
├── dataset/
├── logs/
│   └── detections.csv
├── assets/
└── README.md

## Quick Start
1) Install deps: `pip install -r requirements.txt`
2) (Optional) Add YOLO weights to `models/` (e.g., `yolov8n-waste.pt`).
3) Run: `python main.py`

## Waste Classes
Default classes are in `waste_classes.txt`: recyclable, organic, hazardous, e-waste, other.

## Logs
CSV with columns: timestamp,image_path,category,confidence,notes

## License
MIT
